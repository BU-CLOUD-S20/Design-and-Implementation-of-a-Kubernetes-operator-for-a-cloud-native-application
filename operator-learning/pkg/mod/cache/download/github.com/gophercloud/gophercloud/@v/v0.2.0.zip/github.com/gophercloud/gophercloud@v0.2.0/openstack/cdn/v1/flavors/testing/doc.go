// cdn_flavors_v1
package testing
