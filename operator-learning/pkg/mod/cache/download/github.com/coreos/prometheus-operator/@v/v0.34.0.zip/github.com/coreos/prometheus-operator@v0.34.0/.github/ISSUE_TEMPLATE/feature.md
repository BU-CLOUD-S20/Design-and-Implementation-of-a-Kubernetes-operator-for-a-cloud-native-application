---
name: Feature
about: If you want to propose a new feature or enhancement
labels: kind/feature
---

<!--

Feel free to ask questions in #prometheus-operator on Kubernetes Slack!

-->

**What is missing?**

**Why do we need it?**

**Environment**

* Prometheus Operator version:

    `Insert image tag or Git SHA here`
    <!-- Try kubectl -n monitoring describe deployment prometheus-operator -->

**Anything else we need to know?**:
