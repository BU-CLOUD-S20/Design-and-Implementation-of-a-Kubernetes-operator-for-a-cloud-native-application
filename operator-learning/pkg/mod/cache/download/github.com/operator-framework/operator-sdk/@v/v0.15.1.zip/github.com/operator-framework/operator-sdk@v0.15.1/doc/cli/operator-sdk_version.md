## operator-sdk version

Prints the version of operator-sdk

### Synopsis

Prints the version of operator-sdk

```
operator-sdk version [flags]
```

### Options

```
  -h, --help   help for version
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease

