#!/bin/bash

go run ./hack/generate/gen-cli-doc.go
