# jsonwriter

This directory contains code for writing yaml.MapSlice structures as JSON files.
